package jack.springboot.starter20180309;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Starter20180309Application {

	public static void main(String[] args) {
		SpringApplication.run(Starter20180309Application.class, args);
	}
}
